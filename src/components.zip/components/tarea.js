import React from "react";
import "../style.css";

const Tarea = ({ tarea }) => {
    return (
        <div class="container">
            <h5>{tarea.name}</h5>
            <h5>{`Id: ${tarea.id}`}</h5>
            <h5>{`Materia: ${tarea.materia}`}</h5>
            <h5>{`Puntos: ${tarea.puntos}`}</h5>
            <h5>{`Fecha de entrega: ${tarea.fechaEntrega}`}</h5>
            <h5>{`Fecha de creación: ${tarea.fechaCreacion}`}</h5>
        </div>
    )
}

export default Tarea;