import {Form, Button} from 'react-bootstrap';

const TareasForm = ({onClickFn}) => {
    return (
        <Form onSubmit={onClickFn}>
            <Form.Group className="mb-3" controlId="ID">
                <Form.Label>ID: </Form.Label>
                <Form.Control type="text" placeholder="Introduce ID"/>
            </Form.Group>
            <Form.Group className="mb-3" controlId="Name">
                <Form.Label>Nombre: </Form.Label>
                <Form.Control type="text" placeholder="Introduce nombre"/>
            </Form.Group>
            <Form.Group className="mb-3" controlId="Materia">
                <Form.Label>Materia: </Form.Label>
                <Form.Control type="text" placeholder="Introduce materia"/>
            </Form.Group>
            <Form.Group className="mb-3" controlId="Puntos">
                <Form.Label>Puntos: </Form.Label>
                <Form.Control type="number" placeholder="Introduce puntaje"/>
            </Form.Group>
            <Form.Group className="mb-3" controlId="Fecha">
                <Form.Label>Fecha de entrega: </Form.Label>
                <Form.Control type="date" placeholder="Introduce fecha"/>
            </Form.Group>
            <Button variant="primary" type="submit">
                Submit
            </Button>
        </Form>
    );
}

export default TareasForm