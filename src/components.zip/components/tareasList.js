import {useEffect, useState} from "react";
import Tarea from "./tarea";
import TareaForm from "./tareasForm";
import "../style.css";

const TareasList = () => {

    const [tareas, setTareas] = useState([]);
    const [showForm, setShowForm] = useState(false);

    useEffect(() => {
        fetch("http://localhost:3030/tareas")
            .then((res) => res.json())
            .then((data) => setTareas(data.data))
            .catch((err) => console.log(`Error: ${err}`));
    }, []);

    const createTarea = (data) => {
        try {
            fetch("http://localhost:3030/tareas", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            }).then(response => response.json())
                .then(dataResponse => {
                    setTareas([...tareas, dataResponse.data]);
                    setShowForm(false);
                });
        } catch (err) {
            console.log(err);
        }
    }


    return (
        <div class="container">
            {tareas.map((tarea, index) => (
                <Tarea
                    key={index}
                    index={index}
                    tarea={tarea}
                />
            ))}
            <button class="btn" className="new-btn"
                    onClick={() => setShowForm(!showForm)}>{showForm ? "Cerrar" : "Nueva tarea"}
            </button>
            {showForm && <TareaForm></TareaForm>}
        </div>
    );
}

export default TareasList;